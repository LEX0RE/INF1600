#ifndef EXO1
#define EXO1

short parity(const short c);
short hamming_encoding(const char c);
char  hamming_decoding(const short c);

#endif
